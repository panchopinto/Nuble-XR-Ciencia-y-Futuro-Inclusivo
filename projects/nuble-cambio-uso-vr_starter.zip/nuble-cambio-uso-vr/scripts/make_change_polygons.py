#!/usr/bin/env python3

"""
make_change_polygons.py — ΔdB, máscaras de ganancia/pérdida y polígonos GeoJSON.
Además construye malla OBJ desde DEM y texturas para VR/WebXR.

Uso:
  python make_change_polygons.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --gain_thr 1.5 --loss_thr -1.5 --scale_z 1.2 --step 2

Requisitos: rasterio, numpy, pillow, shapely
"""
import argparse, os, json
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
    from rasterio import features
except Exception:
    rasterio = None

try:
    from shapely.geometry import shape, mapping, Polygon
except Exception:
    shape = None

def norm_0_255(arr, lo=None, hi=None):
    a = arr.astype(float)
    if lo is None: lo = np.nanpercentile(a, 2)
    if hi is None: hi = np.nanpercentile(a, 98)
    a = np.clip((a - lo) / (hi - lo + 1e-9), 0, 1)
    return (a * 255).astype(np.uint8)

def pseudocolor(delta_db):
    a = delta_db.astype(float)
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    a = np.clip((a - lo) / (hi - lo + 1e-9), 0, 1)
    r = (a * 255).astype(np.uint8)
    g = (255 - np.abs(a*2-1)*255).astype(np.uint8)
    b = ((1 - a) * 255).astype(np.uint8)
    return np.dstack([r,g,b])

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)

    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")

    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w)
        ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z

    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])

    def vid(i, j):
        return j*w + i + 1

    for j in range(h-1):
        for i in range(w-1):
            v1 = vid(i,j); v2 = vid(i+1,j); v3 = vid(i+1,j+1); v4 = vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])

    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def polygonize_mask(mask, transform, crs, min_area_pixels=100):
    """Convierte máscara binaria a GeoJSON (filtrando polígonos pequeños)."""
    features_list = []
    for geom, val in features.shapes(mask.astype(np.int16), mask=mask.astype(np.uint8), transform=transform):
        if val == 1:
            poly = shape(geom) if shape else None
            if poly is None or poly.area >= min_area_pixels:
                features_list.append({
                    "type": "Feature",
                    "properties": {},
                    "geometry": geom
                })
    return {
        "type": "FeatureCollection",
        "name": "mask_polygons",
        "crs": {"type": "name", "properties": {"name": str(crs)}} if crs else None,
        "features": features_list
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("t1", help="GeoTIFF backscatter t1 (dB)")
    ap.add_argument("t2", help="GeoTIFF backscatter t2 (dB)")
    ap.add_argument("--dem", help="DEM GeoTIFF", required=True)
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--gain_thr", type=float, default=1.5)
    ap.add_argument("--loss_thr", type=float, default=-1.5)
    ap.add_argument("--scale_z", type=float, default=1.2)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")
    import rasterio

    os.makedirs(args.out_dir, exist_ok=True)

    # Leer rásteres
    with rasterio.open(args.t1) as r1, rasterio.open(args.t2) as r2:
        a1 = r1.read(1).astype(float)
        a2 = r2.read(1).astype(float)
        transform = r1.transform
        crs = r1.crs

    # Normalizados (pantalla) y ΔdB
    Image.fromarray(norm_0_255(a1)).save(os.path.join(args.out_dir, "t1.png"))
    Image.fromarray(norm_0_255(a2)).save(os.path.join(args.out_dir, "t2.png"))
    delta = a2 - a1
    Image.fromarray(pseudocolor(delta)).save(os.path.join(args.out_dir, "delta.png"))

    # Máscaras binarias: ganancia y pérdida
    gain = (delta >= args.gain_thr).astype(np.uint8)*255
    loss = (delta <= args.loss_thr).astype(np.uint8)*255

    # Suavizado opcional para limpiar ruido sal‑pimienta
    gain_img = Image.fromarray(gain).filter(ImageFilter.MedianFilter(size=3))
    loss_img = Image.fromarray(loss).filter(ImageFilter.MedianFilter(size=3))

    gain_img.save(os.path.join(args.out_dir, "mask_gain.png"))
    loss_img.save(os.path.join(args.out_dir, "mask_loss.png"))

    # Poligonización (GeoJSON) — usa la máscara *binaria* antes de normalizar a 0–255
    gain_bool = (delta >= args.gain_thr).astype(np.uint8)
    loss_bool = (delta <= args.loss_thr).astype(np.uint8)

    gain_geo = polygonize_mask(gain_bool, transform, crs, min_area_pixels=100)
    loss_geo = polygonize_mask(loss_bool, transform, crs, min_area_pixels=100)

    with open(os.path.join(args.out_dir, "polygons_gain.geojson"), "w") as f:
        json.dump(gain_geo, f)

    with open(os.path.join(args.out_dir, "polygons_loss.geojson"), "w") as f:
        json.dump(loss_geo, f)

    # Malla desde DEM
    terrain_obj = os.path.join(args.out_dir, "terrain.obj")
    # textura inicial: t2.png
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png="t2.png")

    print("Listo: t1/t2/delta, máscaras y polígonos + terreno OBJ")

if __name__ == "__main__":
    main()
