# Guion didáctico — Cambio de uso de suelo (PIE + PAES)

**Competencias:** interpretar ΔdB SAR, relacionar con procesos (cosechas/incendios/revegetación), evaluar impactos en suelos y comunidades.

## Actividades
1. Observa T1 vs T2 y describe diferencias visibles.
2. Activa `ΔdB` y explica qué representan colores (pseudocolor).
3. Activa `Pérdida` (loss) y `Ganancia` (gain). Localiza parches significativos.
4. Redacta una hipótesis de causa (cosecha, incendio, urbanización). Contrasta con datos locales (municipio/CONAF).
5. Discusión sobre **limitaciones**: cambios por humedad del suelo, ángulo de incidencia, etc.

## Evaluación
- Rúbrica: identificación de áreas de cambio, argumentación de causas, reflexión crítica.
