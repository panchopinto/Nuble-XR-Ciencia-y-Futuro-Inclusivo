# Deforestación y cambio de uso de suelo — VR (Proyecto 4)

Experiencia VR/WebXR para **detectar cambios** entre dos fechas **Sentinel‑1 (GRD RTC)** en el corredor **Chillán ↔ Cobquecura**. Genera **ΔdB**, máscaras de **ganancia/pérdida** y polígonos **GeoJSON**; visualiza en una escena VR conmutando entre T1/T2/ΔdB/Ganancia/Pérdida.

## Objetivo
- Comparar `backscatter_t1.tif` vs `backscatter_t2.tif` (dB) y resaltar **pérdida de cobertura/estructura** (bosque a suelo desnudo, incendios, cosechas) y **ganancia** (revegetación, siembras).

## Flujo
1) Procesa 2 fechas **GRD → RTC** y un **DEM** (SNAP/HyP3).
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow shapely
   python scripts/make_change_polygons.py backscatter_t1.tif backscatter_t2.tif --dem dem.tif --out_dir web/assets --gain_thr 1.5 --loss_thr -1.5
   ```
   Salidas principales en `web/assets/`:
   - `terrain.obj/.mtl` (malla desde DEM)
   - `t1.png`, `t2.png` (texturas normalizadas)
   - `delta.png` (ΔdB pseudocolor)
   - `mask_gain.png`, `mask_loss.png` (transparencias)
   - `polygons_gain.geojson`, `polygons_loss.geojson` (para GIS)
3) Abre `web/index.html` y alterna capas en VR.

## Estructura
```
nuble-cambio-uso-vr/
├─ aoi/
├─ data/{input,processed}
├─ scripts/
├─ web/{assets,css,js}
└─ docs/
```

## Parámetros sugeridos
- **Umbrales en dB**: inicia con `gain_thr=+1.5` y `loss_thr=-1.5` (ajusta según ruido/speckle y fechas).
- Aplica **filtro de mediana** o **apertura morfológica** si la máscara sale ruidosa (ver script).

## Inclusión (PIE) y PAES
- Botones grandes, alto contraste, leyenda clara y descripción de lo que significa **ganancia/pérdida** en dB.
