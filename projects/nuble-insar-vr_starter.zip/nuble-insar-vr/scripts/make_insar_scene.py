#!/usr/bin/env python3

"""
make_insar_scene.py — Construye escena VR con fase envuelta, coherencia y desplazamiento LOS (opcional).

Uso:
  python make_insar_scene.py wrapped_phase.tif coherence.tif --dem dem.tif --out_dir web/assets --scale_z 1.2 --step 2
  python make_insar_scene.py wrapped_phase.tif coherence.tif --dem dem.tif --displacement displacement_los.tif

Requisitos: rasterio, numpy, pillow
"""
import argparse, os
import numpy as np
from PIL import Image, ImageDraw

try:
    import rasterio
except Exception:
    rasterio = None

def color_wheel_phase(phase):
    """Mapea fase [-pi, pi] a rueda HSV."""
    p = (phase + np.pi) / (2*np.pi)  # 0..1
    # HSV hue=p, sat=1, val=1
    h = p; s = np.ones_like(h); v = np.ones_like(h)
    # convertir HSV a RGB
    i = (h*6).astype(int)
    f = (h*6) - i
    i = i % 6
    p0 = v*(1-s)
    q = v*(1-f*s)
    t = v*(1-(1-f)*s)
    r = np.select([i==0,i==1,i==2,i==3,i==4,i==5],[v,q,p0,p0,t,v])
    g = np.select([i==0,i==1,i==2,i==3,i==4,i==5],[t,v,v,q,p0,p0])
    b = np.select([i==0,i==1,i==2,i==3,i==4,i==5],[p0,p0,t,v,v,q])
    rgb = np.dstack([r,g,b])
    return (np.clip(rgb,0,1)*255).astype(np.uint8)

def norm01(a):
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    a = np.clip((a-lo)/(hi-lo+1e-9),0,1)
    return a

def divergence_ramp(a_cm):
    """Escala a -X..+X cm → gris medio en 0, azul negativo, rojo positivo."""
    # cortamos a percentiles para robustez
    lo, hi = np.nanpercentile(a_cm, 2), np.nanpercentile(a_cm, 98)
    a = np.clip((a_cm - 0) / (max(abs(lo),abs(hi))+1e-9), -1, 1)  # -1..1 alrededor de 0
    # map: -1→azul (0,0,255), 0→gris (180), +1→rojo (255,0,0)
    r = np.where(a>=0, 180 + a*(255-180), 180 + a*0)
    g = np.where(a>=0, 180 - a*180, 180 + a*0)
    b = np.where(a>=0, 180 - a*180, 180 + (-a)*(255-180))
    rgb = np.dstack([r,g,b])
    return np.clip(rgb,0,255).astype(np.uint8)

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)

    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")

    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w)
        ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z

    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])

    def vid(i, j):
        return j*w + i + 1

    for j in range(h-1):
        for i in range(w-1):
            v1 = vid(i,j); v2 = vid(i+1,j); v3 = vid(i+1,j+1); v4 = vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])

    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", help="Interferograma fase envuelta (GeoTIFF, radianes -pi..pi)")
    ap.add_argument("coherence", help="Coherencia (GeoTIFF, 0..1)")
    ap.add_argument("--dem", required=True, help="DEM GeoTIFF")
    ap.add_argument("--displacement", help="Desplazamiento LOS (GeoTIFF, metros)")
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--scale_z", type=float, default=1.2)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")
    import rasterio, os

    os.makedirs(args.out_dir, exist_ok=True)

    # Fase envuelta → rueda de color
    with rasterio.open(args.phase) as rp:
        phase = rp.read(1).astype(float)
    # Acotar fase
    phase = np.clip(phase, -np.pi, np.pi)
    phase_png = os.path.join(args.out_dir, "phase.png")
    Image.fromarray(color_wheel_phase(phase)).save(phase_png)

    # Coherencia 0..1 → 0..255
    with rasterio.open(args.coherence) as rc:
        coh = rc.read(1).astype(float)
    coh_n = (np.clip(coh, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(coh_n).save(os.path.join(args.out_dir, "coherence.png"))

    # Desplazamiento opcional (m → cm)
    disp_png = None
    if args.displacement:
        with rasterio.open(args.displacement) as rd:
            disp_m = rd.read(1).astype(float)
        disp_cm = disp_m * 100.0
        disp_png = os.path.join(args.out_dir, "displacement_cm.png")
        Image.fromarray(divergence_ramp(disp_cm)).save(disp_png)
        # leyenda simple
        lg = Image.new("RGB",(256,24),(0,0,0))
        for i in range(256):
            val = (i-128)/128.0  # -1..1
            r = 180 + max(0,val)*(255-180)
            g = 180 - abs(val)*180
            b = 180 + max(0,-val)*(255-180)
            lg.putpixel((i,8),(int(r),int(g),int(b)))
            lg.putpixel((i,9),(int(r),int(g),int(b)))
            lg.putpixel((i,10),(int(r),int(g),int(b)))
        Image.fromarray(np.array(lg)).save(os.path.join(args.out_dir,"legend_disp.png"))

    # leyenda de fase (rueda simplificada)
    wheel = np.zeros((64,256,3),dtype=np.uint8)
    cols = color_wheel_phase(np.linspace(-np.pi,np.pi,256)[None,:].repeat(64,0))
    Image.fromarray(cols).save(os.path.join(args.out_dir,"legend_phase.png"))

    # Construir malla desde DEM (textura por defecto: phase.png)
    terrain_obj = os.path.join(args.out_dir, "terrain.obj")
    tex = "phase.png"
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png=tex)

    print("Listo: phase/coherence (+ displacement si se entrega) y terreno OBJ")

if __name__ == "__main__":
    main()
