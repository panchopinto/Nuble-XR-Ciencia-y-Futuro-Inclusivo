# Guion didáctico — InSAR (PIE + PAES)

**Objetivos:** comprender deformaciones superficiales por sismos/volcanismo, interpretar interferogramas, distinguir fase envuelta vs. desplazamiento LOS.

## Actividades
1. Observa la **fase envuelta**: identifica patrones de franjas y su relación con deformación.
2. Activa **coherencia**: analiza zonas confiables vs. ruido.
3. (Si está) Activa **desplazamiento**: identifica levantamiento/hundimiento relativo en cm.
4. Discute limitaciones: geometría de observación, atmósfera, decorrelación temporal.

## Evaluación
- Rúbrica: lectura de capas, explicación de franjas, conexión con proceso geofísico.
