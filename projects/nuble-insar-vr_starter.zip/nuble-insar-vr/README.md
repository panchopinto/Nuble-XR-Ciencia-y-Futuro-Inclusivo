# InSAR — Deformación sísmica en VR (Proyecto 6)

Experiencia VR/WebXR para visualizar **interferogramas** (fase envuelta), **coherencia** y, si está disponible, **desplazamiento LOS** (desenvuelto) sobre un terreno 3D de Ñuble (Chillán ↔ Cobquecura). Pensado para clases de Geociencias y preparación PIE/PAES.

## Flujo de datos (fuera de este repo)
1) Selecciona **pares SLC IW** (misma órbita/track, baseline ⟂ pequeña) en ASF Vertex/HyP3 o procesa en ESA SNAP.
2) Genera: `wrapped_phase.tif` (fase en radianes -π..π), `coherence.tif` (0..1), **opcional** `displacement_los.tif` (m), y `dem.tif`.
   - HyP3 productos: `INSAR_GAMMA` (interferogram, coherencia) y/o `INSAR_ISCE` (desplazamiento si desenvuelto).
3) Copia esos GeoTIFFs en `data/input/` o a cualquier ruta accesible.

## Construcción de la escena VR
```bash
pip install rasterio numpy pillow
python scripts/make_insar_scene.py wrapped_phase.tif coherence.tif --dem dem.tif --out_dir web/assets --scale_z 1.2
# Opcional si tienes desplazamiento desenvuelto (m):
python scripts/make_insar_scene.py wrapped_phase.tif coherence.tif --dem dem.tif --displacement displacement_los.tif --out_dir web/assets
```
Salidas clave en `web/assets/`:
- `terrain.obj/.mtl` (malla 3D)
- `phase.png` (fase envuelta en rueda de color)
- `coherence.png` (0–1 → 0–255)
- `displacement_cm.png` (si hay desplazamiento; m a cm, rampa diverging gris→azul/rojo)
- `legend_phase.png`, `legend_disp.png` (leyendas simples para VR)

Abre `web/index.html` y cambia **Fase / Coherencia / Desplazamiento**.

## Notas educativas
- **Fase envuelta** muestra franjas (fringes): cada ciclo (−π..π) suele asociarse a ~**λ/2 en LOS** (para Sentinel‑1, λ≈5.6 cm).
- **Coherencia** indica calidad (1=alta). Bajos valores pueden provenir de vegetación, cambios rápidos o geometría desfavorable.
- **Desplazamiento LOS** requiere **desenvoltura** (SNAPHU/ISCE/HyP3) y correcciones; úsalo como aproximación educativa.

## Inclusión (PIE) y PAES
- Botones grandes para cambiar capa, leyendas simples y textos descriptivos; foco en interpretación visual y fenomenología sísmica.
