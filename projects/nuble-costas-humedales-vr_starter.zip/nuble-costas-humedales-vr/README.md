# Erosión de costa y humedales — VR (Proyecto 5)

Experiencia VR/WebXR para estudiar **dinámica costera** (playas, barras, desembocaduras) y **humedales** en la costa de Cobquecura–Buchupureo usando **Sentinel‑1 (GRD RTC)** y **DEM**. Incluye cálculo de **línea de costa** para dos fechas y **mapa de cambio** (ganancia/pérdida de tierra) + capa de humedales por umbral de backscatter.

## Flujo
1) Procesa 2 fechas **GRD → RTC** (VV o VV/VH) y un **DEM** (SNAP/HyP3).
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow shapely
   python scripts/make_coast_change.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --water_thr 0.35
   ```
   Salidas:
   - `terrain.obj/.mtl` (malla desde DEM)
   - `t1.png`, `t2.png` (texturas normalizadas)
   - `water_t1.png`, `water_t2.png` (máscaras de agua)
   - `shoreline_t1.geojson`, `shoreline_t2.geojson` (líneas de costa)
   - `coast_change.geojson` (polígonos de cambio tierra↔agua)
   - `wetlands_mask.png` (humedales por umbral en zonas bajas)
3) Abre `web/index.html` y alterna capas (T1/T2/Agua/Humedales/Cambio).

## Notas metodológicas
- La **línea de costa** se aproxima con umbral sobre backscatter y filtrado; es educativa y **no reemplaza** levantamientos batimétricos ni modelos de oleaje.
- Los **humedales** se infieren combinando zonas de baja cota (DEM) y **backscatter bajo** (suelo saturado/vegetación palustre). Ajusta `--water_thr` según tus rásteres.

## Inclusión (PIE) y PAES
- Botones grandes, leyenda sencilla, explicaciones sobre qué “ve” el radar vs. ojo humano.
