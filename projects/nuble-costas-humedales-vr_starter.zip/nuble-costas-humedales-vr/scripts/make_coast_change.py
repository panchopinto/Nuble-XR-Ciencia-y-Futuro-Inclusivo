#!/usr/bin/env python3

"""
make_coast_change.py — Línea de costa y humedales desde backscatter (educativo) + terreno para VR.

Uso:
  python make_coast_change.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --water_thr 0.35 --scale_z 1.1 --step 2

Parámetros:
  - water_thr: umbral (0–1) sobre backscatter normalizado (valores bajos ≈ agua/superficie lisa).
Requisitos: rasterio, numpy, pillow, shapely
"""
import argparse, os, json
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
    from rasterio import features
except Exception:
    rasterio = None

try:
    from shapely.geometry import shape, mapping, Polygon, MultiPolygon, LineString
    from shapely.ops import unary_union
except Exception:
    shape = None

def norm0_1(arr):
    a = arr.astype(float)
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    a = np.clip((a - lo) / (hi - lo + 1e-9), 0, 1)
    return a

def norm_0_255(arr):
    return (np.clip(arr,0,1)*255).astype(np.uint8)

def build_mask(a01, thr):
    # agua = backscatter bajo
    return (a01 <= thr).astype(np.uint8)

def mask_to_lines(mask, transform, min_len_px=50):
    """Borde de agua-tierra → líneas (muy simplificado)."""
    edges = np.zeros_like(mask, dtype=np.uint8)
    # contorno por diferencia con vecinos (4-neigh)
    edges[1:, :] |= (mask[1:, :] != mask[:-1, :])
    edges[:, 1:] |= (mask[:, 1:] != mask[:, :-1])
    # poligoniza bordes dilatados y extrae líneas aproximadas
    shapes = features.shapes((edges>0).astype(np.int16), mask=(edges>0), transform=transform)
    lines = []
    for geom, val in shapes:
        poly = shape(geom) if shape else None
        if poly is None: continue
        if poly.length >= min_len_px:
            # borde como LineString del polígono (aprox.)
            lines.append(poly.boundary)
    if not lines: return None
    merged = unary_union(lines)
    if isinstance(merged, (LineString, )):
        geoms = [merged]
    else:
        geoms = list(merged.geoms)
    fc = {"type":"FeatureCollection","features":[]}
    for g in geoms:
        fc["features"].append({"type":"Feature","properties":{},"geometry":mapping(g)})
    return fc

def compute_change(mask1, mask2, transform):
    # 1=agua,0=tierra
    # tierra→agua = pérdida; agua→tierra = ganancia
    loss = (mask1==0) & (mask2==1)
    gain = (mask1==1) & (mask2==0)
    def poly(mask):
        feats = []
        for geom, val in features.shapes(mask.astype(np.int16), mask=mask.astype(np.uint8), transform=transform):
            feats.append({"type":"Feature","properties":{},"geometry":geom})
        return feats
    return {
        "type":"FeatureCollection",
        "features": poly(loss) + poly(gain)
    }

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)

    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")

    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w)
        ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z

    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])

    def vid(i, j):
        return j*w + i + 1

    for j in range(h-1):
        for i in range(w-1):
            v1 = vid(i,j); v2 = vid(i+1,j); v3 = vid(i+1,j+1); v4 = vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])

    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("t1", help="GeoTIFF backscatter t1 (dB)")
    ap.add_argument("t2", help="GeoTIFF backscatter t2 (dB)")
    ap.add_argument("--dem", help="DEM GeoTIFF", required=True)
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--water_thr", type=float, default=0.35, help="Umbral (0–1) para agua")
    ap.add_argument("--scale_z", type=float, default=1.1)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")

    import rasterio
    os.makedirs(args.out_dir, exist_ok=True)

    # Leer rásteres
    with rasterio.open(args.t1) as r1, rasterio.open(args.t2) as r2:
        a1 = r1.read(1).astype(float); transform = r1.transform; crs = r1.crs
        a2 = r2.read(1).astype(float)

    # Normalización 0–1 y 0–255 para visualización
    a1n = norm0_1(a1); a2n = norm0_1(a2)
    Image.fromarray((a1n*255).astype(np.uint8)).save(os.path.join(args.out_dir,"t1.png"))
    Image.fromarray((a2n*255).astype(np.uint8)).save(os.path.join(args.out_dir,"t2.png"))

    # Máscaras de agua
    m1 = build_mask(a1n, args.water_thr)
    m2 = build_mask(a2n, args.water_thr)
    # Suavizado ligero
    m1i = Image.fromarray((m1*255).astype(np.uint8)).filter(ImageFilter.MedianFilter(3))
    m2i = Image.fromarray((m2*255).astype(np.uint8)).filter(ImageFilter.MedianFilter(3))
    m1 = (np.array(m1i)>127).astype(np.uint8)
    m2 = (np.array(m2i)>127).astype(np.uint8)
    Image.fromarray(m1*255).save(os.path.join(args.out_dir,"water_t1.png"))
    Image.fromarray(m2*255).save(os.path.join(args.out_dir,"water_t2.png"))

    # Líneas de costa aproximadas
    coast1 = mask_to_lines(m1, transform)
    coast2 = mask_to_lines(m2, transform)
    if coast1:
        with open(os.path.join(args.out_dir,"shoreline_t1.geojson"),"w") as f: json.dump(coast1,f)
    if coast2:
        with open(os.path.join(args.out_dir,"shoreline_t2.geojson"),"w") as f: json.dump(coast2,f)

    # Cambio costa (tierra↔agua)
    change = compute_change(m1, m2, transform)
    with open(os.path.join(args.out_dir,"coast_change.geojson"),"w") as f:
        json.dump(change, f)

    # Humedales: zonas bajas + backscatter bajo (heurística educativa)
    # Como aproximación simple aquí usamos solo backscatter bajo
    wetlands = ((a1n<args.water_thr*1.15) | (a2n<args.water_thr*1.15)).astype(np.uint8)
    Image.fromarray(wetlands*255).save(os.path.join(args.out_dir,"wetlands_mask.png"))

    # Malla desde DEM con textura base t2
    terrain_obj = os.path.join(args.out_dir,"terrain.obj")
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png="t2.png")

    print("Listo: t1/t2, máscaras agua, humedales, líneas de costa y cambio + terreno OBJ")

if __name__ == "__main__":
    main()
