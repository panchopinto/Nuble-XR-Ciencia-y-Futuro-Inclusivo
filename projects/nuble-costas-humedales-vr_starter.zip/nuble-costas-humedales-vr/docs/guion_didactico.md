# Guion didáctico — Costas y humedales (PIE + PAES)

**Objetivos:** interpretar variaciones de línea de costa, reconocer humedales y su rol ecológico, proponer medidas de protección.

## Actividades
1. Observa T1 y T2; identifica cambios en playas/desembocaduras.
2. Activa `Agua` y `Humedales`; explica por qué el radar responde diferente.
3. Revisa `Cambio costa` y propone **acciones** (reforestación de dunas, zonas de amortiguación).
4. Integra con Ciencias/Historia: impactos en comunidades costeras.

## Evaluación
- Comprensión de capas, hipótesis sobre causas (marejadas, crecidas), propuestas de mitigación.
