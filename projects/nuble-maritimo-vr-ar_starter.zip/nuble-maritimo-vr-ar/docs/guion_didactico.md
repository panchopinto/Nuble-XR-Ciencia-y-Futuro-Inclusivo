# Guion didáctico — Acuicultura y tráfico marítimo (PIE + PAES)

**Objetivos:** comprender cómo el radar identifica objetos en el mar; relacionar detecciones con actividades (pesca, transporte, acuicultura).

## Actividades
1. Explora el **mar animado** en VR con la textura SAR (`ocean_tex.png`).
2. Activa **detecciones** (máscara) y ubica barcos/estructuras probables.
3. Analiza **vessels.geojson** en ArcGIS/QGIS y compara con rutas/cartas náuticas.
4. En **AR**, coloca el mini‑mapa en la sala y explica a compañeros qué ves y por qué el radar “brilla” en ciertos puntos.

## Evaluación
- Rúbrica: identificación correcta de objetivos, explicación física (retrodispersión), estrategias de validación (cruces con información externa segura).
