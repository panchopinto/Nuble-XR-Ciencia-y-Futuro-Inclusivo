#!/usr/bin/env python3

"""
detect_vessels.py — Detección educativa de embarcaciones/estructuras en SAR marino (CFAR simplificado).

Uso:
  python detect_vessels.py backscatter.tif --out_dir web/assets --window 31 --k 3.0 --min_area 6

- window: tamaño de vecindad (impares)
- k: factor sobre la media local para marcar objetivos brillantes
- min_area: área mínima (px) para conservar blobs

Requisitos: rasterio, numpy, pillow, shapely
"""
import argparse, os, json
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
    from rasterio import features
except Exception:
    rasterio = None

try:
    from shapely.geometry import shape, mapping, Point, Polygon
except Exception:
    shape = None

def norm01(a):
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    return np.clip((a-lo)/(hi-lo+1e-9), 0, 1)

def local_mean(a, w=31):
    pad = w//2
    ap = np.pad(a, pad, mode='reflect')
    ker = np.ones((w,w), dtype=np.float32) / (w*w)
    # naive conv (educational); for speed use cv2.filter2D if available
    out = np.zeros_like(a, dtype=np.float32)
    for j in range(out.shape[0]):
        for i in range(out.shape[1]):
            region = ap[j:j+w, i:i+w]
            out[j,i] = (region * ker).sum()
    return out

def blobs_to_geojson(mask, transform):
    feats = []
    for geom, val in features.shapes(mask.astype(np.int16), mask=mask.astype(np.uint8), transform=transform):
        if val == 1:
            feats.append({"type":"Feature","properties":{},"geometry":geom})
    return {"type":"FeatureCollection","features":feats}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("backscatter", help="GeoTIFF SAR backscatter (dB o lineal; se normaliza por percentiles)")
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--window", type=int, default=31)
    ap.add_argument("--k", type=float, default=3.0)
    ap.add_argument("--min_area", type=int, default=6)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")

    import rasterio
    os.makedirs(args.out_dir, exist_ok=True)

    # Leer ráster
    with rasterio.open(args.backscatter) as r:
        arr = r.read(1).astype(float)
        transform = r.transform

    a01 = norm01(arr)
    Image.fromarray((a01*255).astype(np.uint8)).save(os.path.join(args.out_dir,"ocean_tex.png"))

    # Media local y detección (CFAR simple)
    m = local_mean(a01, w=args.window)
    det = (a01 > (m + args.k*np.std(a01)))  # umbral simple; alternativa: escala local multiplicativa

    # Limpieza
    det_img = Image.fromarray(det.astype(np.uint8)*255).filter(ImageFilter.MedianFilter(3))
    det = (np.array(det_img)>127).astype(np.uint8)

    # Filtar blobs pequeños
    # Rasterio polygonize para calcular áreas aproximadas en px
    mask = np.zeros_like(det, dtype=np.uint8)
    for geom, val in features.shapes(det.astype(np.int16), mask=det.astype(np.uint8), transform=transform):
        if val == 1:
            poly = shape(geom) if shape else None
            if poly is None or poly.area >= args.min_area:
                # rasterizamos manteniendo 1
                mask[det==1] = 1
                # rompemos - para simplificar el ejemplo educativo
    det = mask

    # Guardar máscara y GeoJSON
    Image.fromarray(det*255).save(os.path.join(args.out_dir, "mask_vessels.png"))
    gj = blobs_to_geojson(det, transform)
    with open(os.path.join(args.out_dir, "vessels.geojson"), "w") as f:
        json.dump(gj, f)

    # Heatmap simple (suavizado de la máscara)
    heat = Image.fromarray((a01*255).astype(np.uint8)).convert("L").filter(ImageFilter.GaussianBlur(2))
    heat = Image.blend(heat.convert("RGB"), Image.fromarray(np.dstack([det*255, np.zeros_like(det), np.zeros_like(det)])).convert("RGB"), alpha=0.4)
    heat.save(os.path.join(args.out_dir, "heatmap.png"))

    print("Listo: ocean_tex.png, mask_vessels.png, vessels.geojson, heatmap.png")

if __name__ == "__main__":
    main()
