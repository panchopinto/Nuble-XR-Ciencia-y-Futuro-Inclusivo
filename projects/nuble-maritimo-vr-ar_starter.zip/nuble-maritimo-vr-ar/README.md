# Monitoreo de acuicultura y tráfico marítimo — VR/AR (Proyecto 7)

Experiencia **VR y AR (WebXR)** para visualizar detecciones **SAR Sentinel‑1** sobre el océano (embarcaciones, estructuras de acuicultura simples) frente a Cobquecura. Incluye:
- Detección educativa por **umbral adaptativo (CFAR simplificado)**.
- Exportación de **GeoJSON** de detecciones.
- Escena **VR** con mar animado y overlays.
- **AR**: colocar un **mini‑mapa 3D** sobre una mesa con *hit‑test*.

## Flujo de datos
1) Procesa una escena **Sentinel‑1 GRD RTC** centrada en mar abierto (VV).
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow shapely
   python scripts/detect_vessels.py backscatter.tif --out_dir web/assets --window 31 --k 3.0 --min_area 6
   ```
   Salidas:
   - `ocean_tex.png` (textura normalizada del backscatter)
   - `mask_vessels.png` (binaria; blancos = detecciones)
   - `vessels.geojson` (puntos/polígonos aproximados)
   - `heatmap.png` (opcional, realce para visual)
3) Abre `web/index.html` para **VR** o `web/ar.html` para **AR** (móvil compatible con WebXR).

## Notas educativas
- El método es **simplificado** (no sustituye vigilancia ni AIS). Sirve para demostrar cómo el radar detecta **objetos metálicos** y **estelas** sobre superficies lisas.
- Ajusta `--window` y `--k` según condiciones de mar y ruido speckle.

## Inclusión (PIE) y PAES
- UI con **botones grandes**, leyenda simple y **modo alto contraste**.
- **AR** facilita el trabajo colaborativo alrededor de una mesa.
