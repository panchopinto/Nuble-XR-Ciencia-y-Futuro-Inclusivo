# Guion didáctico — Agricultura inteligente (PIE + PAES)

**Objetivos:** interpretar mapas de humedad y anomalías; priorizar sectores para riego; proponer un plan de monitoreo.

## Actividades
1. Compara `Humedad T1` vs `Humedad T2`: ¿dónde aumentó/disminuyó?
2. Activa `Anomalía` y `Zonas prioritarias`: selecciona **3 sectores** a intervenir y justifica.
3. Cruza con `Parcelas` (reales o demo) y diseña un **plan de riego** (frecuencia/turnos).
4. En **AR**, coloca el mini‑mapa sobre la mesa y expón tu propuesta al curso.

## Evaluación
- Rúbrica: lectura de capas, priorización fundamentada, claridad del plan y reflexión sobre limitaciones del método.
