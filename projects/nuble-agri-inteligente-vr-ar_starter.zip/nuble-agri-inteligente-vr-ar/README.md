# Agricultura inteligente — VR/AR (Proyecto 10)

Experiencia **VR/AR (WebXR)** para observar **humedad de suelo** y **zonas de riego de precisión** a partir de **Sentinel‑1 (GRD RTC)** en el valle agrícola de Ñuble. Integra **DEM** para un terreno 3D y capas: **Índice de humedad**, **Anomalía T2–T1**, **Parcelas** (aprox.), y **Zonas de riego prioritarias**.

> Uso **educativo**: los índices son aproximados (no reemplazan sensores in‑situ).

## Flujo
1) Prepara `t1.tif` y `t2.tif` (backscatter RTC VV/VH) y `dem.tif`.
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow shapely
   python scripts/make_agri_sm.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --smooth 3 --priority_thr 0.65
   ```
   Salidas en `web/assets/`:
   - `terrain.obj/.mtl` (malla 3D, textura base `moisture_t2.png`)
   - `moisture_t1.png`, `moisture_t2.png` (0–255; más claro ≈ **más húmedo**)
   - `anomaly.png` (T2–T1 pseudocolor)
   - `fields.geojson` (parcelas aprox. desde textura; opcionalmente reemplazar por catastro real)
   - `priority_zones.geojson` (zonas de riego de **alta prioridad**)
   - `legend_anom.png` (leyenda)
3) Abre `web/index.html` (VR) o `web/ar.html` (AR).

## Metodología educativa (simplificada)
- **Humedad proxy**: invertir y normalizar backscatter (humedades altas tienden a suavizar la superficie → menor backscatter en ciertos casos); ojo con efectos de cultivo/ángulo.
- **Anomalía**: diferencia T2–T1 estandarizada → realza cambios de humedad entre fechas.
- **Parcelas**: segmentación simple por textura (puedes sustituir por polígonos oficiales).

## Inclusión (PIE) y PAES
- Botones grandes, leyendas claras, glosario en `docs/` y actividades de toma de decisiones de riego responsable.
