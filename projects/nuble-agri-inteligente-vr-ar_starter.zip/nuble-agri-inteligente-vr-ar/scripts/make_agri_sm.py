#!/usr/bin/env python3

"""
make_agri_sm.py — Índice de humedad (proxy) + anomalía y zonas prioritarias; genera terreno VR/AR.

Uso:
  python make_agri_sm.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --smooth 3 --priority_thr 0.65 --scale_z 1.15 --step 2

Requisitos: rasterio, numpy, pillow, shapely
"""
import argparse, os, json
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
    from rasterio import features
except Exception:
    rasterio = None

try:
    from shapely.geometry import shape, mapping
except Exception:
    shape = None

def norm01(a):
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    return np.clip((a-lo)/(hi-lo+1e-9), 0, 1)

def moisture_proxy(a):
    # Invertimos para que valores altos = más húmedo (educativo)
    a01 = norm01(a)
    return 1.0 - a01

def smooth_im(a01, k=3):
    if k<=1: return a01
    img = Image.fromarray((a01*255).astype(np.uint8)).filter(ImageFilter.MedianFilter(k))
    return np.array(img)/255.0

def pseudocolor_delta(d):
    # d normalizado -1..1 → azul (neg) a rojo (pos)
    dn = np.clip(d, -1, 1)
    r = ((dn>0)* (dn*255)).astype(np.uint8)
    g = (255 - np.abs(dn)*255).astype(np.uint8)
    b = ((dn<0)* (-dn*255)).astype(np.uint8)
    return np.dstack([r,g,b])

def polygonize(mask, transform):
    feats=[]
    for geom, val in features.shapes(mask.astype(np.int16), mask=mask.astype(np.uint8), transform=transform):
        if val==1:
            feats.append({"type":"Feature","properties":{},"geometry":geom})
    return {"type":"FeatureCollection","features":feats}

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)
    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")
    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w); ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z
    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])
    def vid(i,j): return j*w+i+1
    for j in range(h-1):
        for i in range(w-1):
            v1=vid(i,j); v2=vid(i+1,j); v3=vid(i+1,j+1); v4=vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])
    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("t1", help="GeoTIFF backscatter t1")
    ap.add_argument("t2", help="GeoTIFF backscatter t2")
    ap.add_argument("--dem", required=True, help="DEM GeoTIFF")
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--smooth", type=int, default=3)
    ap.add_argument("--priority_thr", type=float, default=0.65, help="umbral para zonas prioritarias (0–1)")
    ap.add_argument("--scale_z", type=float, default=1.15)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")
    import rasterio, os

    os.makedirs(args.out_dir, exist_ok=True)

    # Leer rásteres
    with rasterio.open(args.t1) as r1, rasterio.open(args.t2) as r2:
        a1 = r1.read(1).astype(float); transform = r1.transform
        a2 = r2.read(1).astype(float)

    # Índice de humedad (proxy) 0..1
    m1 = smooth_im(moisture_proxy(a1), args.smooth)
    m2 = smooth_im(moisture_proxy(a2), args.smooth)
    Image.fromarray((m1*255).astype(np.uint8)).save(os.path.join(args.out_dir,"moisture_t1.png"))
    Image.fromarray((m2*255).astype(np.uint8)).save(os.path.join(args.out_dir,"moisture_t2.png"))

    # Anomalía T2–T1 normalizada a -1..1
    # estandarizamos por percentiles robustos
    d = m2 - m1
    p98 = np.nanpercentile(np.abs(d), 98)
    dan = np.clip(d / (p98+1e-9), -1, 1)
    Image.fromarray(pseudocolor_delta(dan)).save(os.path.join(args.out_dir,"anomaly.png"))

    # Parcelas "demo": segmentación simple por textura (m2) para polígonos
    fields_mask = (m2 > 0.4).astype(np.uint8)
    fields = {"type":"FeatureCollection","features":[]}
    for geom, val in features.shapes(fields_mask.astype(np.int16), mask=fields_mask.astype(np.uint8), transform=transform):
        if val==1:
            fields["features"].append({"type":"Feature","properties":{}, "geometry":geom})
    with open(os.path.join(args.out_dir,"fields.geojson"),"w") as f:
        json.dump(fields, f)

    # Zonas de riego prioritarias: humedad baja en T2 (m2<=(1-priority_thr)) o caída fuerte (dan< -0.5)
    low = (m2 <= (1.0 - args.priority_thr)).astype(np.uint8)
    drop = (dan <= -0.5).astype(np.uint8)
    priority = ((low + drop) > 0).astype(np.uint8)
    with open(os.path.join(args.out_dir,"priority_zones.geojson"),"w") as f:
        json.dump({"type":"FeatureCollection","features":[{"type":"Feature","properties":{},"geometry":g} for g,v in features.shapes(priority.astype(np.int16), mask=priority.astype(np.uint8), transform=transform) if v==1]}, f)

    # Malla desde DEM con textura base moisture_t2
    terrain_obj = os.path.join(args.out_dir,"terrain.obj")
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png="moisture_t2.png")

    print("Listo: humedad T1/T2, anomalía, parcelas y zonas prioritarias + terreno OBJ")

if __name__ == "__main__":
    main()
