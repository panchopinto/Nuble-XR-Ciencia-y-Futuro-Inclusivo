# Glaciares andinos y disponibilidad hídrica — VR/AR (Proyecto 8)

Experiencia **VR/AR (WebXR)** para observar **extensión de nieve/hielo** en los Andes centrales y relacionarla con la **oferta hídrica**. Usa **Sentinel‑1 (GRD RTC)** como aproximación educativa (texturas SAR) y **DEM** para hipsometría (área por bandas de altura).

> Nota: Ñuble no tiene grandes glaciares; este set apunta a un **área andina cercana** (Caja AOI incluida). Puedes ajustar el AOI a un glaciar específico (Ejm: Olivares, Yeso, Echaurren).

## Flujo
1) Procesa 2 fechas **GRD → RTC** sobre el AOI y un **DEM**.
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow
   python scripts/make_glacier_change.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --ice_thr 0.35 --elev_step 200
   ```
   Salidas en `web/assets/`:
   - `terrain.obj/.mtl` (malla 3D, textura base `t2.png`)
   - `t1.png`, `t2.png` (texturas normalizadas)
   - `ice_t1.png`, `ice_t2.png` (máscaras nieve/hielo)
   - `ice_change.png` (ganancia/pérdida)
   - `hypsometry.csv` (área por banda de elevación)
   - `legend_change.png` (leyenda simple)
3) Abre `web/index.html` para VR o `web/ar.html` para AR.

## Metodología educativa (simplificada)
- Clasificación nieve/hielo por **umbral** de backscatter normalizado + filtro por **pendiente/elevación** (heurístico).
- Hipsometría: suma de píxeles por bandas de **`--elev_step`** (m). Útil para hablar de **reserva nival** y rol en caudales.

## Inclusión (PIE) y PAES
- Botones grandes, leyendas simples, explicación física de **retrodispersión** y **relación con agua**.
