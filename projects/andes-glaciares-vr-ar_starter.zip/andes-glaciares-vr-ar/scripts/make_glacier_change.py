#!/usr/bin/env python3

"""
make_glacier_change.py — Nieve/Hielo por umbral + hipsometría y escena VR/AR (educativo).

Uso:
  python make_glacier_change.py t1.tif t2.tif --dem dem.tif --out_dir web/assets --ice_thr 0.35 --elev_step 200 --scale_z 1.2 --step 2

Parámetros:
  - ice_thr (0–1): umbral en backscatter normalizado (valores bajos ≈ nieve/hielo/superficie lisa)
  - elev_step: tamaño de banda hipsométrica (m)

Requisitos: rasterio, numpy, pillow
"""
import argparse, os, csv
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
except Exception:
    rasterio = None

def norm01(a):
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    return np.clip((a-lo)/(hi-lo+1e-9),0,1)

def to_uint8(a01):
    return (np.clip(a01,0,1)*255).astype(np.uint8)

def slope_from_dem(dem, res=1.0):
    # gradiente simple central differences
    gy, gx = np.gradient(dem, res, res)
    slope = np.sqrt(gx*gx + gy*gy)
    return slope

def classify_ice(a01, dem, ice_thr):
    # Heurística: a01 bajo (superficie lisa) + elevación alta (+opc. pendiente moderada)
    elev_norm = (dem - np.nanmin(dem)) / (np.nanmax(dem)-np.nanmin(dem)+1e-9)
    elev_mask = elev_norm > 0.3  # preferir cotas medias-altas
    ice = (a01 <= ice_thr) & elev_mask
    return ice.astype(np.uint8)

def hypsometry_table(mask, dem, step, pixel_area=1.0):
    zmin = int(np.nanmin(dem)); zmax = int(np.nanmax(dem))
    bins = list(range((zmin//step)*step, ((zmax//step)+1)*step, step))
    rows = [["z_min","z_max","area_pixels","area_units"]]
    for i in range(len(bins)-1):
        z0, z1 = bins[i], bins[i+1]
        sel = (dem>=z0) & (dem<z1) & (mask==1)
        area_px = int(sel.sum())
        rows.append([z0, z1, area_px, area_px*pixel_area])
    return rows

def write_csv(path, rows):
    with open(path, "w", newline="") as f:
        csv.writer(f).writerows(rows)

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)

    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")

    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w)
        ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z

    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])

    def vid(i, j):
        return j*w + i + 1

    for j in range(h-1):
        for i in range(w-1):
            v1=vid(i,j); v2=vid(i+1,j); v3=vid(i+1,j+1); v4=vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])

    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("t1", help="GeoTIFF backscatter t1 (dB o lineal)")
    ap.add_argument("t2", help="GeoTIFF backscatter t2 (dB o lineal)")
    ap.add_argument("--dem", required=True, help="DEM GeoTIFF")
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--ice_thr", type=float, default=0.35)
    ap.add_argument("--elev_step", type=int, default=200)
    ap.add_argument("--scale_z", type=float, default=1.2)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")
    import rasterio, os

    os.makedirs(args.out_dir, exist_ok=True)

    with rasterio.open(args.t1) as r1, rasterio.open(args.t2) as r2:
        a1 = r1.read(1).astype(float)
        a2 = r2.read(1).astype(float)
        transform = r1.transform
        # pixel area aproximado (si raster ya está proyectado en m); si está en lat/long, esto es simbólico
        pixel_area = abs(transform.a * transform.e) if (transform.a!=0 and transform.e!=0) else 1.0

    # Normalización para visual
    a1n = norm01(a1); a2n = norm01(a2)
    Image.fromarray(to_uint8(a1n)).save(os.path.join(args.out_dir,"t1.png"))
    Image.fromarray(to_uint8(a2n)).save(os.path.join(args.out_dir,"t2.png"))

    # DEM y slope
    with rasterio.open(args.dem) as rd:
        dem = rd.read(1).astype(float)
        dem[dem <= -9999] = np.nan

    # Clasificación hielo/nieve
    ice1 = classify_ice(a1n, dem, args.ice_thr)
    ice2 = classify_ice(a2n, dem, args.ice_thr)
    # suavizado leve
    ice1 = (Image.fromarray(ice1*255).filter(ImageFilter.MedianFilter(3)))
    ice1 = (np.array(ice1)>127).astype(np.uint8)
    ice2 = (Image.fromarray(ice2*255).filter(ImageFilter.MedianFilter(3)))
    ice2 = (np.array(ice2)>127).astype(np.uint8)

    Image.fromarray(ice1*255).save(os.path.join(args.out_dir,"ice_t1.png"))
    Image.fromarray(ice2*255).save(os.path.join(args.out_dir,"ice_t2.png"))

    # Cambio (ganancia en azul, pérdida en rojo, estable en gris claro)
    gain = (ice2==1) & (ice1==0)
    loss = (ice2==0) & (ice1==1)
    change_rgb = np.dstack([loss*255, np.zeros_like(loss), gain*255]).astype(np.uint8)
    Image.fromarray(change_rgb).save(os.path.join(args.out_dir,"ice_change.png"))

    # Hipsometría (área por banda) para T1 y T2
    rows1 = hypsometry_table(ice1, dem, args.elev_step, pixel_area=pixel_area)
    rows2 = hypsometry_table(ice2, dem, args.elev_step, pixel_area=pixel_area)
    # merge por bandas
    # Construimos un CSV con columnas: z_min,z_max,area_t1,area_t2,delta
    header = ["z_min","z_max","area_t1","area_t2","delta"]
    # map by (z_min,z_max)
    def to_map(rows):
        m = {}
        for r in rows[1:]:
            m[(int(r[0]),int(r[1]))] = r[2]
        return m
    m1 = to_map(rows1); m2 = to_map(rows2)
    keys = sorted(set(list(m1.keys())+list(m2.keys())))
    out_rows = [header]
    for k in keys:
        a1k = int(m1.get(k,0)); a2k = int(m2.get(k,0))
        out_rows.append([k[0],k[1],a1k,a2k,a2k-a1k])
    write_csv(os.path.join(args.out_dir,"hypsometry.csv"), out_rows)

    # Construir malla desde DEM (textura base t2.png)
    terrain_obj = os.path.join(args.out_dir,"terrain.obj")
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png="t2.png")

    # Leyenda simple para cambio
    legend = Image.new("RGB",(256,40),(20,20,20))
    for i in range(256):
        r = i; g = 30; b = 255 - i
        for j in range(12,28):
            legend.putpixel((i,j),(r,g,b))
    legend.save(os.path.join(args.out_dir,"legend_change.png"))

    print("Listo: t1/t2, masks ice, change, hypsometry.csv y terreno OBJ")

if __name__ == "__main__":
    main()
