# Guion didáctico — Glaciares e hídrica (PIE + PAES)

**Objetivos:** interpretar cambios en nieve/hielo, entender hipsometría y su vínculo con la disponibilidad hídrica.

## Actividades
1. Observa T1/T2 y activa `Nieve/Hielo` para cada fecha.
2. Revisa `Cambio` (ganancia/pérdida) y discute causas (temperatura, tormentas, polvo, época).
3. Abre `hypsometry.csv`: ¿cómo se distribuye el área por altura? ¿Qué implica para el deshielo?
4. Relaciona con agua potable/riego y riesgos (aluviones).
