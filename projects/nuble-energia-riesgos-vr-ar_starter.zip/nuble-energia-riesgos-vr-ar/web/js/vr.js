AFRAME.registerComponent('layer-switcher', {
  init: function(){
    const mesh = document.querySelector('#mesh');
    const ovS = document.querySelector('#ov-streams');
    const ovH = document.querySelector('#ov-hydro');
    const setTex = id => mesh.setAttribute('material','src','#'+id);

    document.querySelector('#btn-slope').addEventListener('click', ()=>setTex('tex-slope'));
    document.querySelector('#btn-rough').addEventListener('click', ()=>setTex('tex-rough'));
    document.querySelector('#btn-hazard').addEventListener('click', ()=>setTex('tex-hazard'));
    document.querySelector('#btn-flow').addEventListener('click', ()=>setTex('tex-flow'));
    document.querySelector('#btn-streams').addEventListener('click', ()=>ovS.setAttribute('visible', !ovS.getAttribute('visible')));
    document.querySelector('#btn-hydro').addEventListener('click', ()=>ovH.setAttribute('visible', !ovH.getAttribute('visible')));
  }
});
document.addEventListener('DOMContentLoaded', ()=>{
  const terrain = document.querySelector('#terrain');
  if (terrain) terrain.setAttribute('layer-switcher','');
});