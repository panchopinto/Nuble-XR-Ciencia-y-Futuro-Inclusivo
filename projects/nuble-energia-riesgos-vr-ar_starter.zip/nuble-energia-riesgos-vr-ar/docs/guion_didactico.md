# Guion didáctico — Energía y riesgos (PIE + PAES)

**Objetivos:** interpretar pendiente, rugosidad SAR y acumulación de flujo; proponer **sitios potenciales** para microhidro; identificar **zonas de riesgo** (deslizamientos) y **rutas/zonas seguras** (discusión).

## Actividades
1. Observa `Pendiente` y `Rugosidad` en VR. ¿Dónde se combinan altos valores?
2. Activa `Riesgo`: localiza laderas críticas. ¿Qué comunidades/infrastructura quedarían expuestas?
3. Activa `Ríos` y `Potencial hidro`: elige 2–3 sitios y justifica con pendiente y flujo.
4. En AR, coloca el mini‑mapa y explicad en grupo vuestras propuestas y medidas de mitigación.

## Evaluación
- Rúbrica: lectura correcta de capas, criterios técnicos básicos, propuestas factibles y responsables.
