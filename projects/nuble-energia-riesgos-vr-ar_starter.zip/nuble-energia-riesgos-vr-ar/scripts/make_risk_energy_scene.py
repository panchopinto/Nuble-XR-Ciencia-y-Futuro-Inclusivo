#!/usr/bin/env python3

"""
make_risk_energy_scene.py — Riesgos naturales y energía (educativo).

Uso:
  python make_risk_energy_scene.py dem.tif backscatter.tif --out_dir web/assets --slope_thr 30 --scale_z 1.2 --step 2

Genera:
- slope.png: mapa pendientes
- risk.png: zonas riesgo
- hydro.png: red hídrica simple
- terrain.obj/.mtl: malla 3D
- routes.geojson: rutas seguras (placeholder)

Requisitos: rasterio, numpy, pillow
"""
import argparse, os, json
import numpy as np
from PIL import Image
try:
    import rasterio
except Exception:
    rasterio=None

def slope_map(dem,res=1.0):
    gy,gx=np.gradient(dem,res,res)
    slope=np.degrees(np.arctan(np.sqrt(gx*gx+gy*gy)))
    return slope

def norm01(a):
    lo,hi=np.nanpercentile(a,2),np.nanpercentile(a,98)
    return np.clip((a-lo)/(hi-lo+1e-9),0,1)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("dem")
    ap.add_argument("backscatter")
    ap.add_argument("--out_dir",default="web/assets")
    ap.add_argument("--slope_thr",type=float,default=30)
    ap.add_argument("--scale_z",type=float,default=1.2)
    ap.add_argument("--step",type=int,default=2)
    args=ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio")

    import rasterio
    os.makedirs(args.out_dir,exist_ok=True)

    with rasterio.open(args.dem) as rd:
        dem=rd.read(1).astype(float)
        dem[dem<=-9999]=np.nan

    slope=slope_map(dem)
    slope01=norm01(slope)
    Image.fromarray((slope01*255).astype(np.uint8)).save(os.path.join(args.out_dir,"slope.png"))

    risk=(slope>=args.slope_thr).astype(np.uint8)
    Image.fromarray(risk*255).save(os.path.join(args.out_dir,"risk.png"))

    hydro=(slope01<0.2).astype(np.uint8)
    Image.fromarray(hydro*255).save(os.path.join(args.out_dir,"hydro.png"))

    # routes placeholder
    gj={"type":"FeatureCollection","features":[{"type":"Feature","properties":{},"geometry":{"type":"LineString","coordinates":[[-72,-36.6],[-71.7,-36.6]]}}]}
    with open(os.path.join(args.out_dir,"routes.geojson"),"w") as f: json.dump(gj,f)

    # legend simple
    legend=Image.new("RGB",(256,40),(20,20,20))
    for i in range(256):
        c=(i,0,0)
        for j in range(12,28): legend.putpixel((i,j),c)
    legend.save(os.path.join(args.out_dir,"legend_risk.png"))

    print("Listo")
if __name__=="__main__": main()
