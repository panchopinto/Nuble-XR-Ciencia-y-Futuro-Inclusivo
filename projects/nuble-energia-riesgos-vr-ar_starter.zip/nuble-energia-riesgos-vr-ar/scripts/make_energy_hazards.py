#!/usr/bin/env python3

"""
make_energy_hazards.py — Índices educativos de riesgo (laderas) y potencial hidro + terreno VR/AR.

Uso:
  python make_energy_hazards.py dem.tif backscatter.tif --out_dir web/assets --fa_thr 200 --slope_min 0.02 --slope_max 0.10 --scale_z 1.2 --step 2

Requisitos: rasterio, numpy, pillow
"""
import argparse, os, json
import numpy as np
from PIL import Image, ImageFilter

try:
    import rasterio
    from rasterio import features
except Exception:
    rasterio = None

def norm01(a):
    lo, hi = np.nanpercentile(a, 2), np.nanpercentile(a, 98)
    return np.clip((a-lo)/(hi-lo+1e-9),0,1)

def slope_percent(dem, resx=1.0, resy=1.0):
    gy, gx = np.gradient(dem, resy, resx)
    slope = np.sqrt(gx*gx + gy*gy)
    return slope * 100.0

def local_std(a, w=9):
    pad = w//2
    ap = np.pad(a, pad, mode='reflect')
    out = np.zeros_like(a, dtype=np.float32)
    for j in range(out.shape[0]):
        for i in range(out.shape[1]):
            r = ap[j:j+w, i:i+w]
            out[j,i] = r.std()
    return out

# D8 flow accumulation (sencillo; educativo)
def flow_accum_d8(dem):
    h, w = dem.shape
    acc = np.ones_like(dem, dtype=np.float32) # cada celda cuenta 1
    # direcciones D8 calculadas por mayor descenso
    # iteración simple (no optimizada, educativa)
    for _ in range(200):  # iteraciones suficientes para propagar en zonas pequeñas
        changed = False
        for j in range(1,h-1):
            for i in range(1,w-1):
                z = dem[j,i]
                # vecinos
                nbrs = [
                    (j-1,i-1), (j-1,i), (j-1,i+1),
                    (j,  i-1),           (j,  i+1),
                    (j+1,i-1), (j+1,i), (j+1,i+1)
                ]
                dz = [z - dem[y,x] for (y,x) in nbrs]
                if max(dz) > 0: # hay descenso
                    k = np.argmax(dz)
                    y,x = nbrs[k]
                    # transfiere una pequeña fracción (relajación)
                    tr = 0.1*acc[j,i]
                    if tr>0:
                        acc[y,x] += tr
                        acc[j,i] -= tr
                        changed = True
        if not changed: break
    return acc

def write_obj(out_obj, vertices, faces, uvs=None, texture_png=None):
    mtl_name = os.path.splitext(os.path.basename(out_obj))[0] + ".mtl"
    out_mtl = os.path.join(os.path.dirname(out_obj), mtl_name)
    with open(out_obj, "w") as f:
        if texture_png:
            f.write(f"mtllib {mtl_name}\nusemtl material0\n")
        for v in vertices:
            f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
        if uvs is not None:
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for face in faces:
            if uvs is not None:
                f.write(f"f {face[0]}/{face[0]} {face[1]}/{face[1]} {face[2]}/{face[2]}\n")
            else:
                f.write(f"f {face[0]} {face[1]} {face[2]}\n")
    if texture_png:
        with open(out_mtl, "w") as m:
            m.write("newmtl material0\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\n")
            m.write(f"map_Kd {os.path.basename(texture_png)}\n")

def build_mesh_from_dem(dem_tif, out_obj, scale_z=1.0, step=2, tex_png=None):
    import rasterio
    with rasterio.open(dem_tif) as src:
        dem = src.read(1).astype(float)
        dem[dem <= -9999] = np.nan
        dem = dem[::step, ::step]
        h, w = dem.shape
        xs = np.linspace(0, 1, w); ys = np.linspace(0, 1, h)
        X, Y = np.meshgrid(xs, ys)
        Z = np.nan_to_num(dem, nan=np.nanmean(dem))
        Z = (Z - np.nanmin(Z)) / (np.nanmax(Z) - np.nanmin(Z) + 1e-9)
        Z *= scale_z
    vertices, uvs, faces = [], [], []
    for j in range(h):
        for i in range(w):
            vertices.append([X[j, i], Z[j, i], 1.0 - Y[j, i]])
            uvs.append([i/(w-1), j/(h-1)])
    def vid(i, j): return j*w + i + 1
    for j in range(h-1):
        for i in range(w-1):
            v1=vid(i,j); v2=vid(i+1,j); v3=vid(i+1,j+1); v4=vid(i,j+1)
            faces.append([v1,v2,v3]); faces.append([v1,v3,v4])
    os.makedirs(os.path.dirname(out_obj), exist_ok=True)
    write_obj(out_obj, vertices, faces, uvs=uvs, texture_png=tex_png)

def polygonize(mask, transform):
    feats=[]
    for geom, val in features.shapes(mask.astype(np.int16), mask=mask.astype(np.uint8), transform=transform):
        if val==1:
            feats.append({"type":"Feature","properties":{},"geometry":geom})
    return {"type":"FeatureCollection","features":feats}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dem", help="DEM GeoTIFF (m)")
    ap.add_argument("backscatter", help="SAR backscatter (GeoTIFF)")
    ap.add_argument("--out_dir", default="web/assets")
    ap.add_argument("--fa_thr", type=float, default=200.0)
    ap.add_argument("--slope_min", type=float, default=0.02) # 2%
    ap.add_argument("--slope_max", type=float, default=0.10) # 10%
    ap.add_argument("--scale_z", type=float, default=1.2)
    ap.add_argument("--step", type=int, default=2)
    args = ap.parse_args()

    if rasterio is None:
        raise RuntimeError("Instala rasterio: pip install rasterio")
    import rasterio, os

    os.makedirs(args.out_dir, exist_ok=True)

    # Cargar datos
    with rasterio.open(args.dem) as rd:
        dem = rd.read(1).astype(float); transform = rd.transform
    with rasterio.open(args.backscatter) as rb:
        bs = rb.read(1).astype(float)

    # Pendiente (%)
    slope = slope_percent(dem)
    slope_n = (np.clip(slope, 0, 100) / 100.0 * 255).astype(np.uint8)
    Image.fromarray(slope_n).save(os.path.join(args.out_dir,"slope.png"))

    # Rugosidad SAR (desv. estándar local)
    bs01 = norm01(bs); rough = local_std(bs01, w=9)
    rough_n = (norm01(rough) * 255).astype(np.uint8)
    Image.fromarray(rough_n).save(os.path.join(args.out_dir,"roughness.png"))

    # Riesgo de deslizamiento (índice simple): pendiente_n * rough_n
    risk = norm01(slope) * norm01(rough)
    risk_n = (risk*255).astype(np.uint8)
    Image.fromarray(risk_n).save(os.path.join(args.out_dir,"hazard_landslide.png"))
    # binario alto riesgo
    risk_mask = (risk > 0.6).astype(np.uint8)
    with open(os.path.join(args.out_dir,"hazard_zones.geojson"),"w") as f:
        json.dump(polygonize(risk_mask, transform), f)

    # Acumulación de flujo (D8 simple)
    acc = flow_accum_d8(dem)
    acc_n = (norm01(np.log1p(acc)) * 255).astype(np.uint8)
    Image.fromarray(acc_n).save(os.path.join(args.out_dir,"flow_accum.png"))
    streams = (acc > args.fa_thr).astype(np.uint8)
    Image.fromarray(streams*255).save(os.path.join(args.out_dir,"streams.png"))

    # Potencial hidro: cauce AND pendiente entre [min,max] (en fracción)
    slope_frac = np.clip(slope/100.0,0,1)
    hydro = (streams==1) & (slope_frac >= args.slope_min) & (slope_frac <= args.slope_max)
    Image.fromarray(hydro.astype(np.uint8)*255).save(os.path.join(args.out_dir,"hydro_potential.png"))
    with open(os.path.join(args.out_dir,"hydro_sites.geojson"),"w") as f:
        json.dump(polygonize(hydro.astype(np.uint8), transform), f)

    # Malla desde DEM (textura base = slope.png)
    terrain_obj = os.path.join(args.out_dir,"terrain.obj")
    build_mesh_from_dem(args.dem, terrain_obj, scale_z=args.scale_z, step=args.step, tex_png="slope.png")

    print("Listo: pendiente, rugosidad, riesgo, acumulación, ríos y potencial hidro + terreno OBJ")

if __name__ == "__main__":
    main()
