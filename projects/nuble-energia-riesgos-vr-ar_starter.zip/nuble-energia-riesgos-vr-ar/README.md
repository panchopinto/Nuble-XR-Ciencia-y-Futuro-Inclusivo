# Energía y riesgos naturales — VR/AR (Proyecto 9)

Experiencia **VR/AR (WebXR)** para planificar de forma **educativa**: 
- **Riesgo de remociones en masa (deslizamientos)** a partir de **pendiente (DEM)** y **rugosidad SAR**.
- **Potencial hidroeléctrico micro/mini** con proxy sencillo: **acumulación de flujo (DEM)** + **pendiente 2–10%**.

Incluye scripts para generar capas, escena **VR** conmutando entre **Pendiente / Rugosidad / Riesgo / Potencial hidro / Ríos**, y escena **AR** con mini‑mapa colocable. **No reemplaza** estudios profesionales.

## Flujo
1) Prepara `dem.tif` (proyectado en metros) y `backscatter.tif` (Sentinel‑1 RTC).
2) Ejecuta:
   ```bash
   pip install rasterio numpy pillow
   python scripts/make_energy_hazards.py dem.tif backscatter.tif --out_dir web/assets --fa_thr 200 --slope_min 0.02 --slope_max 0.10
   ```
   Salidas principales:
   - `terrain.obj/.mtl` (malla 3D con textura base `slope.png`)
   - `slope.png` (pendiente %), `roughness.png` (rugosidad SAR local)
   - `hazard_landslide.png` y `hazard_zones.geojson`
   - `flow_accum.png`, `streams.png` (binaria), `hydro_potential.png`, `hydro_sites.geojson`
3) Abre `web/index.html` (VR) o `web/ar.html` (AR).

## Parámetros
- `--fa_thr`: umbral de **acumulación de flujo** (px) para definir cauces.
- `--slope_min/--slope_max`: rango de **pendiente** (en fracción, 0.02=2%) para potencial hidro educativo.

## Inclusión (PIE) y PAES
- Botones grandes, leyendas simples, y textos de ayuda para interpretar cada capa.
